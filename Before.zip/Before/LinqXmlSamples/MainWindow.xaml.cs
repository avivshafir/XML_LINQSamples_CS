﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml;
using System.Xml.Linq;
using LINQSamples_CS;

namespace LinqXmlSamples
{
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();
    }

    private void btnTryIt_Click(object sender, RoutedEventArgs e)
    {
      StringBuilder sb = new StringBuilder(1024);
      XElement doc;

      doc = XElement.Load(AppConfig.GetMenuFile());

      XElement elem = (from node in doc.Elements("Menu")
                       where node.Element("MenuID").Value == "910"
                       select node).SingleOrDefault();

      if (elem != null)
      {
        elem.Remove();

        doc.Save(AppConfig.GetMenuFile());
      }
    }
  }
}

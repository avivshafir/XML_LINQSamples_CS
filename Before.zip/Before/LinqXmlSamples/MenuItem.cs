﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinqXmlSamples
{
  public class MenuItem
  {
    public string MenuId { get; set; }
    public string MenuText { get; set; }
    public int DisplayOrder { get; set; }
    public string Action { get; set; }

    public override string ToString()
    {
      return MenuText;
    }
  }
}
